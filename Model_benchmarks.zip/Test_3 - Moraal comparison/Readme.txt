This folder contain subfolders corresponding to the different radial dependences used by Caballero-Lopez & Moraal. The subfolders are labelled according to the radial dependence of the diffusion coefficient. The "ref" folder contain the simulations that are independent on radial position. For the different radial dependences, the magnitude of the diffusion coefficient at 1AU is accordingly changed to that the modulation paramater for all simulations are the same. See again the Caballero-Lopez & Moraal paper. 

To run the Python3.0 models in each subfoler, the command line can be used:

(base) fskrdts@fskrdts-HP-EliteBook-835-G7-Notebook-PC:~/Downloads/1D modulation model/Du Toit version/Test_3 - Moraal comparison/r+05$ python Moraal_model.py 

The same can be used for the plotting subroutine in the top folder:

(base) fskrdts@fskrdts-HP-EliteBook-835-G7-Notebook-PC:~/Downloads/1D modulation model/Du Toit version/Test_3 - Moraal comparison/r+05$ python plot_output.py 
