import matplotlib.pyplot as plt
import numpy as np

#-------------------------------------------------------------

E_ref_1AU = np.array([2.7843,7.056,14.094,42.17,101.67,257.67,540.97,1489.6,3796,7540.6])
J_ref_1AU = np.array([0.033537,0.090163,0.18454,0.54976,1.1391,1.7003,1.4731,0.6265,0.14957,0.03648])

E_ref_80AU = np.array([2.3583,4.1937,6.1441,7.9697,10.569,13.043,16.276,20.995,28.153,40.567,58.456,101.67,200.86,351.3,737.54,1497.9,3493.6])
J_ref_80AU = np.array([0.035864,0.069326,0.11427,0.18402,0.41618,0.86924,1.775,3.544,6.2491,9.844,12.793,14.364,11.89,8.0242,3.4862,1.2077,0.2516])

E_p1_1AU = np.array([5.4097,10.224,16.276,24.925,39.025,51.468,75.824,111.71,168.25])
J_p1_1AU = np.array([0.022644,0.060106,0.12013,0.22178,0.40488,0.55656,0.838,1.1789,1.4982])

E_p1_80AU = np.array([2.1824,2.649,3.1623,3.9025,4.633,6.1782,8.47,11.612,17.202,27.083,43.353,67.878,105.11,172.97,261.98,405.67,571.76,762.45,1062.8,1441,1953.7,2723.3])
J_p1_80AU = np.array([0.26264,0.54233,1.1454,2.5031,4.2639,8.2307,14.03,19.29,24.511,26.893,27.886,24.958,21.59,17.066,12.317,8.3071,5.4132,3.6482,2.2464,1.3988,0.83243,0.42769])

E_p05_1AU = np.array([4.0343,6.6392,12.138,20.995,36.517,62.125,100.56,178.81,299.2,476.3,733.47,1193.8,1838.3,2424.5,3025.3,4056.7,5320.6])
J_p05_1AU = np.array([0.027719,0.056042,0.12839,0.25382,0.46889,0.79113,1.219,1.7165,1.9054,1.7643,1.41,0.9405,0.57287,0.39045,0.28154,0.16195,0.09857])

E_p05_80AU = np.array([2.3845,3.059,3.9899,5.1184,6.1102,7.5824,9.945,12.138,14.896,19.11,26.637,44.324,64.58,101.67,165.48,270.83,421.7,621.25,837.68,1154.8,1627.6,2231.3])
J_p05_80AU = np.array([0.055133,0.077511,0.11796,0.22257,0.43428,0.993,2.4034,4.0946,6.4447,9.807,14.27,18.143,18.804,18.424,15.065,10.877,7.2538,4.6746,3.0801,1.9843,1.1161,0.62774])

E_m1_80AU = np.array([6.3166,11.109,17.107,22.813,29.591,38.81,53.798,86.596,153.14,235.83,367.2,529.12,709.51,1005.6,1333.5,1828.2,2293.9])
J_m1_80AU = np.array([0.079568,0.14534,0.30389,0.68729,1.4037,2.7714,5.2309,8.1516,9.154,8.285,6.3285,4.515,3.2567,2.0283,1.3669,0.80439,0.53585])

E_m05_80AU = np.array([3.0086,4.6587,6.9783,10.866,13.939,17.393,22.067,28.783,38.81,63.869,98.35,153.99,231.94,311.02,438.36,591.06,783.85,1098.7,1506.2,2182.4,3059])
J_m05_80AU = np.array([0.039756,0.063359,0.10211,0.17815,0.32126,0.63411,1.3397,2.7054,5.1638,9.1145,11.197,11.096,9.489,7.84,5.8517,4.3176,3.0445,1.896,1.1284,0.62061,0.32617])
#-------------------------------------------------------------
data = np.loadtxt("./ref/output.txt", skiprows = 0, delimiter = ',')

T = data[0:,0]
F = data[0:,1]
F80 = data[0:,2]
FLIS = data[0:,3]

data = np.loadtxt("./r+1/output.txt", skiprows = 0, delimiter = ',')

T_p1 = data[0:,0]
F_p1 = data[0:,1]
F80_p1 = data[0:,2]

data = np.loadtxt("./r+05/output.txt", skiprows = 0, delimiter = ',')

T_p05 = data[0:,0]
F_p05 = data[0:,1]
F80_p05 = data[0:,2]

data = np.loadtxt("./r-05/output.txt", skiprows = 0, delimiter = ',')

T_m05 = data[0:,0]
F_m05 = data[0:,1]
F80_m05 = data[0:,2]

data = np.loadtxt("./r-1/output.txt", skiprows = 0, delimiter = ',')

T_m1 = data[0:,0]
F_m1 = data[0:,1]
F80_m1 = data[0:,2]
#-------------------------------------------------------------

fig = plt.figure(figsize = (15,10))

subplot1 = fig.add_subplot(111)
subplot1.set_xlim(1,1e4)
subplot1.set_ylim(1e-2, 1e2)
#subplot1.set_title('Parker Solar Probe', fontsize = 14)
subplot1.set_xlabel('Kinetic energy (MeV)', fontsize = 16)
subplot1.set_ylabel('Differential intensity', fontsize = 16)
subplot1.set_yscale('log')
subplot1.set_xscale('log')
subplot1.tick_params(labelsize = 14)

subplot1.plot(T,F, color = 'red', label = 'Python: $\kappa \sim r^{0}$')
subplot1.scatter(E_ref_1AU, J_ref_1AU, marker = 'o', edgecolor = 'red', facecolor = 'none', label = 'Fortran: $\kappa \sim r^{0}$')

subplot1.plot(T,F80, color = 'red')
subplot1.scatter(E_ref_80AU, J_ref_80AU, marker = 'o', edgecolor = 'red', facecolor = 'none')

subplot1.plot(T_p1,F_p1, color = 'blue', label = 'Python: $\kappa \sim r^{+1}$', linestyle = '--')
subplot1.scatter(E_p1_1AU, J_p1_1AU, marker = 's', edgecolor = 'blue', facecolor = 'none', label = 'Fortran: $\kappa \sim r^{+1}$')

subplot1.plot(T_p1,F80_p1, color = 'blue', linestyle = '--')
subplot1.scatter(E_p1_80AU, J_p1_80AU, marker = 's', edgecolor = 'blue', facecolor = 'none')

subplot1.plot(T_p05,F_p05, color = 'green', label = 'Python: $\kappa \sim r^{+0.5}$', linestyle = '-.')
subplot1.scatter(E_p05_1AU, J_p05_1AU, marker = '<', edgecolor = 'green', facecolor = 'none', label = 'Fortran: $\kappa \sim r^{+0.5}$')

subplot1.plot(T_p05,F80_p05, color = 'green', linestyle = '-.')
subplot1.scatter(E_p05_80AU, J_p05_80AU, marker = '<', edgecolor = 'green', facecolor = 'none')

subplot1.plot(T_m1,F_m1, color = 'purple', label = 'Python: $\kappa \sim r^{-1}$', linestyle = '-.')

subplot1.plot(T_m1,F80_m1, color = 'purple', linestyle = '-.')
subplot1.scatter(E_m1_80AU, J_m1_80AU, marker = '>', edgecolor = 'purple', facecolor = 'none', label = 'Fortran: $\kappa \sim r^{-1}$')\

subplot1.plot(T_m05,F_m05, color = 'orange', label = 'Python: $\kappa \sim r^{-0.5}$', linestyle = ':')

subplot1.plot(T_m05,F80_m05, color = 'orange', linestyle = ':')
subplot1.scatter(E_m05_80AU, J_m05_80AU, marker = '^', edgecolor = 'orange', facecolor = 'none', label = 'Fortran: $\kappa \sim r^{-0.5}$')

subplot1.plot(T,FLIS, color = 'black', label = 'LIS', linewidth = 2)

subplot1.legend(ncol = 2, fontsize = 14)
      
fig.savefig('output.png', dpi=300, bbox_inches='tight')

plt.show()
